;(function($) {
  $.fn.ukVideoBg = function(options) {
    const opts = $.extend({}, $.fn.ukVideoBg.defaults, options);

    return this.each(function(i, e) {
      const _this = $(e);
      const video_bg_wrap = 'uk_video_bg_wrap';
      let movie, video_item, ratio;


      // video_bg_wrap append ------------------------------------------------------------------------------------------
      _this.append(
        '<div class="'+video_bg_wrap+'" style="position:'+opts.VideoWrapPosition+'; left:0; top:0; z-index:'+opts.VideoWrapZIndex+'; width:100%; height:100%; overflow:hidden; background-color:'+opts.VideoWrapBgColor+';">' +
        '<span class="uk_video_bg_cover" style="position:absolute; left:0; top:0; right:0; bottom:0; z-index:1; background-color:'+opts.coverColor+'; opacity:'+opts.coverOpacity+';"></span>' +
        '</div>'
      );


      // video tag -----------------------------------------------------------------------------------------------------
      if( opts.videoUrl ){
        movie = opts.videoUrl;
        const type = movie.split('.')[movie.split('.').length-1];
        video_item =
          '<video autoplay loop muted style="position:absolute; left:50%; top:50%; transform:translate(-50%, -50%); width:auto; height:auto; min-width:100%; min-height:100%; object-fit:cover;">' +
          '<source src="'+movie+'" type="video/'+type+'">' +
          '</video>';
        $('.'+video_bg_wrap).append(video_item);
        if( opts.videoPoster ){
          $('.'+video_bg_wrap).find('video').attr('poster',opts.videoPoster);
        }
      }


      // youtube -------------------------------------------------------------------------------------------------------
      else{
        movie = opts.youtubeId;
        const youtube_option = 'autoplay=1&fs=0&mute=1&controls=0&autohide=0&modestbranding=0&rel=0&wmode=opaque&showinfo=0&version=3&playlist='+movie+'&loop=1&vq=hd1080'
        video_item =
          '<iframe src="https://www.youtube.com/embed/'+movie+'?'+youtube_option+'" ' +
          'style="position:absolute; left:50%; top:50%; transform:translate(-50%, -50%); width:100%; height:100%;" ' +
          'frameBorder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>';
        $('.'+video_bg_wrap).append(video_item);

        const _video_bg_player = $('.'+video_bg_wrap).find('iframe');

        let ratio_start = true;
        function youtube_json(callback){
          $.getJSON('https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v='+movie+'&format=json', function(data){
            callback(data);
          }).always(function() {
            if( ratio_start ){
              youtube_json(function(data){
                ratio = data.width/data.height;
              });
              $(window).trigger('resize');
              ratio_start = false;
            }
          });
        }

        const title_hide_size = 120;
        $(window).resize(function(){
          if( opts.youtube_ratio ){
            ratio = opts.youtube_ratio;
          }
          else{
            youtube_json(function(data){
              ratio = data.width/data.height;
            });
          }
          let mw = $(window).width();
          let mh = Math.ceil(mw/ratio);
          let wmh = $(window).height();
          if( opts.title_hide ){
            mw = $(window).width() + title_hide_size;
            mh = Math.ceil(mw/ratio);
            wmh = $(window).height() + title_hide_size;
          }
          _video_bg_player.css({'width':mw, 'height':mh});
          if( wmh > mh ){
            mw = Math.ceil(wmh*2);
            _video_bg_player.css({'width':mw, 'height':wmh});
          }
        }).trigger('resize');
      }
    });
  };


  // default option ----------------------------------------------------------------------------------------------------
  $.fn.ukVideoBg.defaults = {
    VideoWrapBgColor : '#000',          // [string] .uk_video_bg_wrap 의 background-color
    VideoWrapPosition : 'fixed',        // [string] .uk_video_bg_wrap 의 position
    VideoWrapZIndex : -9999,            // [number] .uk_video_bg_wrap 의 z-index
    coverColor : '#000',                // [string] .uk_video_bg_cover 의 background-color (이미지로 적용시 값을 'transparent'로 적용 후 클래스를 이용하여 background-image 적용)
    coverOpacity : 0.7,                 // [number] .uk_video_bg_cover 의 투명도

    // [video tag (video 와 youtube 둘 다 등록 시 video 우선 적용)]
    // videoUrl : 'img/sample.mp4',        // [string] 동영상 경로
    // videoPoster : 'img/poster.jpg',     // [string] poster 이미지 경로

    // [youtube movie]
    // youtubeId : 'VuZYY2etJmw',          // [string] youtube 동영상 id
    // youtube_ratio : 16/9,               // [number] 동영상 비율 | 기본 (16/9), 값이 없을 경우 youtube에 등록된 기본 크기값을 받아와 적용합니다.
    // title_hide : true,                  // [boolean] youtube의 타이틀을 가리기 위해 동영상 확장
  };
}(jQuery));