/**
 * ukFullpage 1.0.0
 * Copyright 2019 kyo-Sung, Chu
 * Released under the kyo-Sung, Chu License
 * Released on: August 15, 2019
 * 단순한 전체 페이지 슬라이더 플러그인 입니다, 최대 9개(footer 포함)의 Section까지 가능합니다.
 * It's a simple full page slider plugin
 */


const
  linear = 'linear',
  ease = 'ease',
  easeIn = 'ease-in',
  easeOut = 'ease-out',
  easeInOut = 'ease-in-out',
  easeInSine = 'cubic-bezier(0.47, 0, 0.745, 0.715)',
  easeOutSine = 'cubic-bezier(0.39, 0.575, 0.565, 1)',
  easeInOutSine = 'cubic-bezier(0.445, 0.05, 0.55, 0.95)',
  easeInQuad = 'cubic-bezier(0.55, 0.085, 0.68, 0.53)',
  easeOutQuad = 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
  easeInOutQuad = 'cubic-bezier(0.455, 0.03, 0.515, 0.955)',
  easeInCubic = 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
  easeOutCubic = 'cubic-bezier(0.215, 0.61, 0.355, 1)',
  easeInOutCubic = 'cubic-bezier(0.645, 0.045, 0.355, 1)',
  easeInQuart = 'cubic-bezier(0.895, 0.03, 0.685, 0.22)',
  easeOutQuart = 'cubic-bezier(0.165, 0.84, 0.44, 1)',
  easeInOutQuart = 'cubic-bezier(0.77, 0, 0.175, 1)',
  easeInQuint = 'cubic-bezier(0.755, 0.05, 0.855, 0.06)',
  easeOutQuint = 'cubic-bezier(0.23, 1, 0.32, 1)',
  easeInOutQuint = 'cubic-bezier(0.86, 0, 0.07, 1)',
  easeInExpo = 'cubic-bezier(0.95, 0.05, 0.795, 0.035)',
  easeOutExpo = 'cubic-bezier(0.19, 1, 0.22, 1)',
  easeInOutExpo = 'cubic-bezier(1, 0, 0, 1)',
  easeInCirc = 'cubic-bezier(0.6, 0.04, 0.98, 0.335)',
  easeOutCirc = 'cubic-bezier(0.075, 0.82, 0.165, 1)',
  easeInOutCirc = 'cubic-bezier(0.785, 0.135, 0.15, 0.86)',
  easeInBack = 'cubic-bezier(0.6, -0.28, 0.735, 0.045)',
  easeOutBack = 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
  easeInOutBack = 'cubic-bezier(0.68, -0.55, 0.265, 1.55)';


// prev 클릭 시 페럴렉스 안되는 문제 해결 필요 -------------------------------------------------------------------------

;(function($) {
  $.fn.ukFullpage = function(options) {
    const opts = $.extend({}, $.fn.ukFullpage.defaults, options);

    return this.each(function(i, e) {
      const _this = $(e);
      const uk_fp_wrap =         'uk_fp_wrap';
      const uk_fp_header_nav =   'uk_fp_header_nav';
      const uk_fp_container =    'uk_fp_container';
      const uk_fp_section =      'uk_fp_section';
      const uk_fp_footer =       'uk_fp_footer';
      const uk_fp_prevNext_box = 'uk_fp_prevNext_box';
      const uk_fp_parallax =     'uk_fp_parallax';
      const fp_section_fixed =   'fp_section_fixed';
      const ft_out_footer =      'ft_out_footer';
      const fp_moving =          'fp_moving';
      const fp_prev_next_btn =   'fp_prev_next_btn';
      const fp_prev_btn =        'fp_prev_btn';
      const fp_next_btn =        'fp_next_btn';
      const fp_next_footer =     'fp_next_footer';
      const page_active =        'page_active';
      const nav_active =         'nav_active';
      const _fpContainer = _this.find('.uk_fp_container');
      const _fpSection = _fpContainer.children();
      const footer_mv_speed = 0.7;
      let lstLength = _fpSection.length;
      let winH;
      let footerHeight;
      let c_Idx;
      let footer_moving = false;
      let device_check = false;
      _this.addClass(uk_fp_wrap);
      if( opts.parallax ) _this.addClass(uk_fp_parallax);
      _fpSection.addClass(uk_fp_section);

      const _fpHeaderNav = _this.find('.'+uk_fp_header_nav);
      const _fpFooter = _this.find('.'+uk_fp_footer);
      const footerVisible = _fpFooter.is(':visible');
      const footerVisible_footerNameTrue = footerVisible && opts.footerName !== '';
      const footerVisible_footerNameFalse = footerVisible && opts.footerName === '';


      // ------------------------------------------------------------------------------------------------------------------------------------


      // 문자 옵션을 변수로 변경
      opts.easing = eval(opts.easing);

      // footer가 container의 형제로 있을 시
      if( _fpContainer.siblings('.'+uk_fp_footer).is(':visible') ){
        lstLength += 1;
        _this.addClass(ft_out_footer);
      }

      // section 초과 시 메시지
      if( lstLength > 9 ){
        const msg = '현재 '+lstLength+'개의 Section이 존재합니다.\n' +
          'ukFullpage는 최대 9개(footer 포함)의 Section만 가능합니다.\n' +
          '9개를 초과할 시 오류가 발생할 수 있습니다.\n' +
          '그래도 진행하시겠습니까?';
        if (confirm(msg) !== true){
          return false;
        }
      }

      // footerName 지정 시 customNameArr 텍스트 변경(푸터 순서에 해당하는 배열)
      if( footerVisible_footerNameTrue ){
        opts.customNameArr[lstLength-1] = opts.footerName;
      }

      // 주소 변경
      function urlReplace(idx){
        if( opts.customName ){
          window.location.replace( '#'+opts.customNameArr[idx] );
        }
        else{
          if( footerVisible_footerNameTrue && idx === lstLength-1 ){
            window.location.replace( '#'+opts.footerName );
          }
          else{
            window.location.replace( '#'+opts.sectionName+(idx+1) );
          }
        }
      }

      // active action
      function activeAction(idx, timing){
        // page active
        let speed = timing;
        if( speed === '' || speed === undefined ) speed = opts.speed;
        if( footer_moving ) speed = opts.speed * footer_mv_speed;

        setTimeout(function(){
          if( opts.activeRepeat ){
            //if( Math.abs((ft_before_idx-1) - idx) === 1 ){
            if( !_this.is('.'+fp_moving) ){
              _fpSection.eq(idx).addClass(page_active).siblings().removeClass(page_active);
            }
          }
          else {
            _fpSection.eq(idx).addClass(page_active);
          }
        }, speed);

        setTimeout(function(){
          if( opts.nav ) _fp_verticalNav.attr('data-active','active_'+(idx+1));
        }, speed/2);

        // nav active
        if( opts.nav ) _fp_verticalNav_li.eq(idx).addClass(nav_active).siblings().removeClass(nav_active);
        if( _fpHeaderNav.length ) _fp_hdNav_li.eq(idx).addClass(nav_active).siblings().removeClass(nav_active);
      }

      // vertical animate
      let ft_before_idx;
      let moving_height;
      function verticalAnimate(idx){
        // uk_fp_footer가 있을 경우
        if( footerVisible ){
          // footer로 갈 때
          if( idx === lstLength-1 ){
            // footer 바로 전에서 footer로 이동
            if( ft_before_idx === lstLength-2 ){
              footer_moving = true;
              moving_height = (winH*(idx-1)) + _this.find('.'+uk_fp_footer).outerHeight();
              action(moving_height, true);
              ft_before_idx = idx;
            }
            // footer 바로 전 외에서 footer로 이동
            else{
              footer_moving = false;
              moving_height = (winH*(idx-1)) + _this.find('.'+uk_fp_footer).outerHeight();
              action(moving_height);
              ft_before_idx = idx;
            }
          }
          // footer에서 올라갈 때
          else{
            // footer에서 바로 위로 이동
            if( idx === lstLength-2 && ft_before_idx === lstLength-1 ){
              footer_moving = true;
              moving_height = (winH*(idx-1)) + _this.find('.'+uk_fp_footer).outerHeight();
              action(winH*idx, true);
              ft_before_idx = idx;
            }
            // footer에서 바로 위 외 이동
            else{
              footer_moving = false;
              action(winH*idx);
              ft_before_idx = idx;
            }
          }
        }
        // uk_fp_footer가 없을 경우
        else{
          action(winH*idx);
        }

        // scroll action
        function action(height, footer_move){
          let mv_speed;
          if( footer_move ){
            mv_speed = opts.speed * footer_mv_speed;
          }
          else{
            mv_speed = opts.speed;
          }

          if( opts.parallax ){
            let eachY;
            const sSpeed = opts.parallaxSpeed;
            _fpSection.each(function(j, k){
              if( footerVisible && idx === lstLength-1 ){
                eachY = (((winH * (j - idx))) * sSpeed) + ((winH * sSpeed) - footerHeight) ;
                if( j === lstLength-1 && $(k).is('.'+uk_fp_section) ){
                  eachY = winH - footerHeight;
                }
              }
              else{
                eachY = winH * (j - idx);
                if( j < idx ){
                  eachY = eachY * sSpeed;
                }
              }
              // eachY = ((winH * (j - idx))/2) + (winH/2 - footerHeight) ;
              // if( j < idx ) eachY = eachY/2;
              // console.log('------------------------------------------------------------------------');
              // console.log( j, idx, eachY );
              $(k).css({'transform':'translateY('+eachY+'px)', 'transition-duration':''+mv_speed*0.001+'s', 'transition-timing-function':opts.easing});
            });
          }
          else{
            _fpContainer.css({'transform':'translateY(-'+height+'px)', 'transition-duration':''+mv_speed*0.001+'s', 'transition-timing-function':opts.easing});
          }

          if( ft_before_idx !== idx ){
            _this.addClass(fp_moving);
          }
          setTimeout(function(){
            _this.removeClass(fp_moving);
            moving = false;
            tMoving = false;
          }, mv_speed/2);
        }

        footer_out();
      }

      // 속도 없는 vertical animate
      function verticalAnimateNone(idx){
        if( opts.parallax ){
          let eachY;
          const sSpeed = opts.parallaxSpeed;
          _fpSection.each(function(j, k){
            if( footerVisible && idx === lstLength-1 ){
              eachY = (((winH * (j - idx))) * sSpeed) + ((winH * sSpeed) - footerHeight) ;
              if( j === lstLength-1 && $(k).is('.'+uk_fp_section) ){
                eachY = winH - footerHeight;
              }
            }
            else{
              eachY = winH * (j - idx);
              if( j < idx ){
                eachY = eachY * sSpeed;
              }
            }
            $(k).not('.'+uk_fp_footer).addClass(fp_section_fixed);
            $(k).css({'transform':'translateY('+eachY+'px)', 'transition-duration':'0s'});
          });
        }
        else{
          let openHeight;
          if( footerVisible && idx === lstLength-1 ){
            openHeight = (winH*(idx-1)) + footerHeight;
          }
          else{
            openHeight = winH*idx;
          }
          _fpContainer.css({'transform':'translateY(-'+openHeight+'px)', 'transition-duration':'0s'});
        }

        footer_out();
      }

      // 푸터 일 경우 이전 section 의 Next 버튼에 클래스 부여
      function footer_out(){
        if( footerVisible ){
          const this_target = _this.find('.'+uk_fp_section).not('.'+uk_fp_footer);
          if( c_Idx === lstLength-1 ){
            let this_length =  this_target.length;
            this_target.eq(this_length-1).find('.'+fp_next_btn).addClass(fp_next_footer);
          }
          else{
            this_target.find('.'+fp_next_footer).removeClass(fp_next_footer);
          }
        }

      }


      // resize --------------------------------------------------------------------------------------------------------
      $('html').css('overflow','hidden');
      const ft_position = 'fixed absolute';
      let resize_oneMore = null;
      $(window).on('resize', function(){
        resizeAction();

        clearTimeout(resize_oneMore);
        resize_oneMore = setTimeout(function(){
          resizeAction();
        }, 200);
      }).trigger('resize');

      function resizeAction(){
        winH = $(window).height();
        footerHeight = Math.floor( _fpFooter.outerHeight() );

        _fpSection.not('.'+uk_fp_footer).css('height',winH);
        verticalAnimateNone(c_Idx);

        if( footerVisible && ft_position.match(_fpFooter.css('position')) ){
          _this.css('padding-bottom',footerHeight);
        }
      }


      // 메뉴 생성 및 클릭 액션 ----------------------------------------------------------------------------------------

      // 세로 메뉴 생성
      let _fp_verticalNav, _fp_verticalNav_li;
      if( opts.nav ){
        _this.append('<nav class="uk_fp_vertical_nav"><ul></ul></nav>');
        _fp_verticalNav = _this.find('.uk_fp_vertical_nav');
        navAppend(_fp_verticalNav.children());

        _fp_verticalNav_li = _fp_verticalNav.find('li');
        if( opts.navShape ) _fp_verticalNav.addClass('fn_shape');
        if( opts.navTooltip ) _fp_verticalNav.addClass('fn_tooltip');

        _fp_verticalNav_li.on('click', function(){
          c_Idx = $(this).index();
          nacClickActive(c_Idx);
          return false;
        });
      }
      
      // header 메뉴 생성
      let _fp_hdNav_ul, _fp_hdNav_li;
      if( _fpHeaderNav.length ){
        _fpHeaderNav.append('<ul>');
        _fp_hdNav_ul = _fpHeaderNav.children();
        navAppend(_fp_hdNav_ul);

        _fp_hdNav_li = _fp_hdNav_ul.find('li');

        _fp_hdNav_li.on('click', function(){
          c_Idx = $(this).index();
          nacClickActive(c_Idx);
          return false;
        });
      }

      // 메뉴 생성 및 클릭 액션
      function navAppend(target){
        let navNaming;
        for( i=0; i<lstLength; i++ ){
          if( opts.customName ){
            navNaming = opts.customNameArr[i];
            target.append('<li><a href="#'+navNaming+'" data-title="'+navNaming+'">'+navNaming+'</a></li>');
          }
          else{
            navNaming = opts.sectionName+' '+(i+1);
            if( footerVisible_footerNameTrue && i === lstLength-1 ){
              target.append('<li><a href="#'+opts.footerName+'" data-title="'+opts.footerName+'">'+opts.footerName+'</a></li>');
            }
            else{
              target.append('<li><a href="#'+opts.sectionName+'" data-title="'+navNaming+'">'+navNaming+'</a></li>');
            }
          }

          if( footerVisible && i === lstLength-1 ){
            target.children().eq(i).addClass('footer_link');
          }
        }
      }
      function nacClickActive(idx){
        _this.addClass('clickAction');

        verticalAnimate(idx);
        urlReplace(idx);
        activeAction(idx);
      }


      // device check --------------------------------------------------------------------------------------------------
      if( navigator.platform ){
        if( navigator.userAgent.indexOf('Mobile') !== -1 ){
          device_check = true;
          _fp_verticalNav.addClass('device');
        }
        else{
          device_check = false;
          _fp_verticalNav.addClass('desktop');
        }
      }


      // 휠 이벤트 -----------------------------------------------------------------------------------------------------
      let sctIdx = 0;
      let moving = false;

      if(document.addEventListener){
        document.addEventListener("mousewheel", MouseWheelHandler(), false);
        document.addEventListener("DOMMouseScroll", MouseWheelHandler(), false);
      }
      else{
        sq.attachEvent("onmousewheel", MouseWheelHandler());
      }

      function MouseWheelHandler() {
        return function (e) {
          // cross-browser wheel delta
          var e = window.event || e;
          let delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));

          if( !moving ){
            if( _this.is('.clickAction') ){} sctIdx = c_Idx;

            //Scroll Down
            if( delta < 0 ){
              if( sctIdx < lstLength-1 ) sctIdx++;
            }

            //Scroll UP
            else{
              if( sctIdx > 0 ) sctIdx--;
            }

            //console.log(sctIdx)

            moving = true;
            c_Idx = sctIdx;
            _this.removeClass('clickAction');

            verticalAnimate(sctIdx);
            urlReplace(sctIdx);
            activeAction(sctIdx);

            return false;
          }
        }
      }


      // 터치 이벤트 ---------------------------------------------------------------------------------------------------
      let startY, endY, moving_size;
      let tMoving = false;
      const minimum_move = opts.minimumTouch;
      if( device_check ){
        _this.find('.'+uk_fp_container+', .'+uk_fp_footer).on({
          touchstart:function(e){
            startY = e.pageY || e.originalEvent.touches[0].pageY;
          },

          touchmove:function(e){
            e.preventDefault();
            endY = e.pageY || e.originalEvent.changedTouches[0].pageY;
            moving_size = Math.abs(startY - endY);
          },

          touchend:function(e){
            if( _this.is('.clickAction') ) sctIdx = c_Idx;

            if( !_this.is('.'+fp_moving) ) {
              if( !tMoving ){
                //down
                if( startY > endY && moving_size > minimum_move ){
                  if( sctIdx < lstLength-1 ){
                    sctIdx++;
                  }
                }

                //up
                else if( startY < endY && moving_size > minimum_move ){
                  if( sctIdx > 0 ){
                    sctIdx--;
                  }
                }
              }

              tMoving = true;
              c_Idx = sctIdx;
              _this.removeClass('clickAction');

              verticalAnimate(sctIdx);
              urlReplace(sctIdx);
              activeAction(sctIdx);
            }

            moving_size = 0;
          }
        });
      }


      // 페이지 오픈 시 파라미더 주소 추가 및 새로고침 시 현재 위치 기억 -----------------------------------------------
      const lcUrl = location.href;
      const defaultUrl = lcUrl.split('/')[lcUrl.split('/').length-1];

      let sectionNameState = opts.sectionName;
      if( opts.customName ) sectionNameState = opts.customNameArr[0];
      console.log(c_Idx);
      console.log(defaultUrl);

      // open
      if( c_Idx === undefined || c_Idx === '' ){
        c_Idx = 0;
        sctIdx = 0;

        urlReplace(0);
        activeAction(0, 0);

        //_fpSection.eq(0).addClass(page_active);
        //if( opts.nav ) _fp_verticalNav.attr('data-active','active_'+1);

        if( opts.parallax ) verticalAnimateNone(0);
      }
      // open 이후(새로고침)
      else{
        const thisUrl = defaultUrl.split('#')[1];
        let thisNum = Math.floor( thisUrl.replace( /[^0-9]/g, "" ).slice(0, 1) -1 );

        // customName = true
        if( opts.customName ){
          if( thisUrl.match(opts.sectionName) ){
            thisNum = thisUrl.replace(opts.sectionName, '')-1;
            urlReplace(thisNum);
          }
          else{
            $.each(opts.customNameArr, function(j, k){
              if(k === thisUrl){
                thisNum = j;
              }
            });
          }

          if( footerVisible_footerNameTrue ){
            replaceUrl();
          }
          else if( footerVisible_footerNameFalse ){
            replaceUrl();
          }
          function replaceUrl(){
            setTimeout(function(){
              thisNum = _fp_verticalNav.find('.'+nav_active).index();
              sctIdx = thisNum;
              urlReplace(thisNum);
            }, 200);
          }
        }

        // customName = false
        else{
          $.each(opts.customNameArr, function(j, k){
            if(k === thisUrl){
              thisNum = j;
              urlReplace(thisNum);
            }
          });

          if( footerVisible_footerNameTrue ){
            if( thisNum === lstLength-1 ){
              window.location.replace( '#'+opts.footerName );
            }
          }
          else if( footerVisible_footerNameFalse ){
            if( opts.sectionName !== thisUrl && thisNum !== lstLength-1 ){
              thisNum = lstLength-1;
              urlReplace(thisNum);
            }
          }
        }

        c_Idx = thisNum;
        sctIdx = thisNum;
        ft_before_idx = thisNum;

        verticalAnimateNone(thisNum);
        activeAction(thisNum, 0);
      }


      // 각 페이지의 이전, 다음 버튼 --------------------------------------------------------------------------------------
      if( opts.prevNextButtons ){
        _fpSection.each(function(j, k){
          let up_down_link = '';
          const move_txt = '_move';
          const top_btn_txt = opts.prevButtonText;
          const down_btn_txt = opts.nextButtonText;
          if( opts.customName ){
            up_down_link += '<button type="button" data-move-number="'+(j-1)+'" data-title="'+opts.customNameArr[j-1]+move_txt+'" class="'+fp_prev_next_btn+' '+fp_prev_btn+'"><i>'+top_btn_txt+'</i></button>';
            up_down_link += '<button type="button" data-move-number="'+(j+1)+'" data-title="'+opts.customNameArr[j+1]+move_txt+'" class="'+fp_prev_next_btn+' '+fp_next_btn+'"><i>'+down_btn_txt+'</i></button>';
          }
          else{
            let ud_idx = j+1;
            up_down_link += '<button type="button" data-move-number="'+(ud_idx-1)+'" data-title="'+opts.sectionName+(ud_idx-1)+move_txt+'" class="'+fp_prev_next_btn+' '+fp_prev_btn+'"><i>'+top_btn_txt+'</i></button>';
            up_down_link += '<button type="button" data-move-number="'+(ud_idx+1)+'" data-title="'+opts.sectionName+(ud_idx+1)+move_txt+'" class="'+fp_prev_next_btn+' '+fp_next_btn+'"><i>'+down_btn_txt+'</i></button>';
          }

          if( opts.prevNextWrap ){
            $(k).append(
              '<div class="'+uk_fp_prevNext_box+'">'+up_down_link+'</div>'
            );
          }
          else{
            $(k).append(up_down_link);
          }
        });

        _fpSection.first().find('.'+fp_prev_btn).remove();
        if( !_this.is('.'+ft_out_footer) ) _fpSection.last().find('.'+fp_next_btn).remove();
        if( footerVisible ){
          _this.find('.'+uk_fp_footer+' .'+fp_prev_btn).remove();
          _this.find('.'+uk_fp_footer+' .'+fp_next_btn).remove();
        }

        _this.find('.'+fp_prev_btn+', .'+fp_next_btn).on('click', function(){
          let ud_idx = Number( $(this).attr('data-move-number') );
          if( !opts.customName ) ud_idx = ud_idx - 1;

          // 일반 Prev, Next 클릭 시
          if( !$(this).is('.'+fp_next_footer) ){
            c_Idx = ud_idx;
            sctIdx = ud_idx;
          }
          // 버튼에 .fp_next_footer 클래스가 있을 시
          else{
            ud_idx = ud_idx - 1;
            c_Idx = ud_idx;
            sctIdx = ud_idx;
            $(this).removeClass(fp_next_footer);
          }

          verticalAnimate(ud_idx);
          urlReplace(ud_idx);
          activeAction(ud_idx);

          return false
        });
      }


      // 탑버튼 --------------------------------------------------------------------------------------------------------
      if( opts.goTopButton ){
        _this.append('<button type="button" class="uk_fp_gotop"><i>'+opts.goTopButtonText+'</i></button>');
        $('.uk_fp_gotop').on('click', function(){
          c_Idx = 0;
          sctIdx = 0;

          verticalAnimate(0);
          urlReplace(0);
          activeAction(0);

          return false;
        });
      }


      // 포커스 관리 ---------------------------------------------------------------------------------------------------
      const fp_click_on = 'fp_click_on';
      _this.find('.'+uk_fp_section+' *, .'+uk_fp_footer+' *').on({
        focus:function(){
          if( !_this.is('.'+fp_click_on) ){
            let focus_idx;
            if( $(this).parents('.'+uk_fp_section).is(':visible') ){
              focus_idx = $(this).parents('.'+uk_fp_section).index();
            }
            else if( $(this).parents('.'+uk_fp_footer).is(':visible') && !$(this).parents('.'+uk_fp_section).is(':visible') ){
              focus_idx = lstLength - 1;
            }
            c_Idx = focus_idx;
            sctIdx = focus_idx;
            ft_before_idx = focus_idx;

            verticalAnimateNone(focus_idx);
            urlReplace(focus_idx);
            activeAction(focus_idx, 0);
          }
        },
        mousedown:function(){  _this.addClass(fp_click_on);  },
        touchstart:function(){  _this.addClass(fp_click_on);  },
        mouseup:function(){  _this.removeClass(fp_click_on);  },
        touchend:function(){  _this.removeClass(fp_click_on);  },
      });
    });
  };


  // default option ----------------------------------------------------------------------------------------------------
  $.fn.ukFullpage.defaults = {
    // 세로 네비 설정 [css로 가로 네비 사용 가능]
    nav : true,                     // [boolean] 사용 유/무
    navShape : false,               // [boolean] 네비 모양 (false:텍스트 기본 / true:원모양(또는 커스텀))
    navTooltip : false,             // [boolean] 말풍선 (navShape가 true로 설정되야 사용 가능)

    // nav 이름 설정
    sectionName : 'Section',        // [string] 각 section 기본 네이밍
    customName : false,             // [boolean] 각 section 이름 지정 (true : customNameArr에 지정한 이름 사용 / 미사용 : sectionName 사용)
    customNameArr : ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'sixth', 'seventh', 'eighth', 'ninth'],
    //└────────────── 이름 지정 시 사용, 페이지 갯수에 맞게 이름 추가
    footerName : 'Footer',          // [string] 푸터 이름 지정 (지정 시 nav와 주소에 선언한 값 노출 / .uk_fp_footer 클래스 명으로 지정된 footer가 존재해야함)

    // active class 컨트롤
    activeRepeat: false,            // [boolean] true : active 반복 적용 / false : 각 section 마다 active 최초 한번만 적용

    // 세로 이동 애니메이션 설정
    speed : 800,                    // [number] 세로 이동 속도
    easing : 'easeInOutCubic',      // [string] 세로 이동 효과
    minimumTouch: 50,               // [number] 최소 터치 거리(설정 값 이상 터치해야 touch move 작동)

    // parallax
    parallax : false,               // [boolean] parallax 애니메이션 사용 여부
    parallaxSpeed : 0.5,            // [number] parallax 속도

    // prev, next 버튼 설정
    prevNextButtons : true,         // [boolean] 각 페이지 위, 아래 버튼 (Class : fp_prev_btn / fp_next_btn)
    prevNextWrap : false,           // [boolean] 위 아래 버튼을 div로 감싸기 여부 (.uk_fp_prevNext_box)
    prevButtonText : 'Prev',        // [string] 이전 버튼 텍스트
    nextButtonText : 'Next',        // [string] 다음 버튼 텍스트

    // 맨 위로 버튼 설정
    goTopButton : true,             // [boolean] 사용 유/무 (Class : uk_fp_gotop)
    goTopButtonText : 'top'         // [string] 버튼 텍스트
  };
}(jQuery));