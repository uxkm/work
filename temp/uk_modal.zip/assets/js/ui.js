$(function(){
  const modal_wrap = 'modal_wrap';
  const modal_button = 'data-modal-button';
  const modal_layer = 'data-modal-layer';
  const modal_dim = 'data-modal-dim';
  const modal_active = 'modal_active';
  let modal_hover = false;
  $('['+modal_button+']').on('click', function(){
    const _target = $(this).attr(modal_button);
    $('['+modal_layer+'="'+_target+'"]').addClass(modal_active);
    $('html').css('overflow','hidden');
    return false;
  });

  $('[data-modal-close]').on('click', function(){
    if( $(this).parents('.'+modal_wrap).is('.'+modal_active) ){
      $('html').removeAttr('style');
      $(this).parents('.'+modal_wrap).removeClass(modal_active);
      modal_hover = false;
    }
    return false;
  });

  $('.'+modal_wrap).on('click', function(e){
    if( $(this).has(e.target).length === 0 && $(this).attr(modal_dim) !== 'false' ){
      $(this).removeClass(modal_active);
      $('html').removeAttr('style');
    }
  });
});

